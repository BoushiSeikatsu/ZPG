#pragma once
class Callbacks
{
private:
	//static void 
public:
	static void initialize();
};

