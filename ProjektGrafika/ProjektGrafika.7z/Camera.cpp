#include "Camera.h"
//�J�����̓X�t�B�A�����ĂāA�X�t�B�A�͐U��Ԃ��Ă���
Camera::Camera()
{
	this->cameraPosition = glm::vec3(0.0f, 0.0f, 6.0f);
	this->cameraFront = glm::vec3(0.0001f, 0.0f, 0.0f);//If x = 0 then first frame doesnt draw objects because matrix has nan values -> its because of our up value set to (0,1,0)
	this->cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
	this->viewMatrix = glm::lookAt(this->cameraPosition, this->cameraPosition + this->cameraFront, this->cameraUp);
	this->projectionMatrix = glm::perspective(glm::radians(60.0f), 4.0f / 3.0f, 0.1f, 100.0f);
}

glm::mat4 Camera::getView()
{
	return this->viewMatrix;
}

glm::vec3 Camera::getCameraPosition()
{
	return this->cameraPosition;
}

glm::vec3 Camera::getCameraFront()
{
	return this->cameraFront;
}

glm::vec3 Camera::getCameraUp()
{
	return this->cameraUp;
}

bool Camera::setCameraPosition(glm::vec3 cameraPosVector)
{
	this->cameraPosition = cameraPosVector;
	viewMatrix = glm::lookAt(this->cameraPosition, this->cameraPosition + this->cameraFront, this->cameraUp);
	//Notify shader that both camera position and camera's view changed, camera position is important for light reflection and view is for setting camera view
	notifyPropertyChanged(CAMERA_POSITION);
	notifyPropertyChanged(CAMERA_VIEW);
	return true;
}

bool Camera::setCameraFront(glm::vec3 cameraFrontVector)
{
	this->cameraFront = cameraFrontVector;
	viewMatrix = glm::lookAt(this->cameraPosition, this->cameraPosition + this->cameraFront, this->cameraUp);
	//notifyPropertyChanged(CAMERA_POSITION);
	notifyPropertyChanged(CAMERA_VIEW);
	return true;
}

glm::mat4 Camera::getProjection()
{
	return this->projectionMatrix;
}

bool Camera::addFollower(Observer* follower)
{
	followers.push_back(follower);
	return true;
}

void Camera::notifyPropertyChanged(OBSERVABLE_OBJECTS type)
{
	switch (type)
	{
		case CAMERA_VIEW:
		{
			for (Observer* observer : followers)
			{
				observer->update(this->viewMatrix, type);
			}
			break;
		}
		//Ready in case we would like to implement zoom in our application
		//For now its used only in initialization process when we setup perspective for the first time
		case CAMERA_PERSPECTIVE:
		{
			for (Observer* observer : followers)
			{
				observer->update(this->projectionMatrix, type);
			}
			break;
		}
		case CAMERA_POSITION:
		{
			for (Observer* observer : followers)
			{
				observer->update(this->cameraPosition, type);
			}
			break;
		}
		default:
		{
			printf("Wrong observable object type!\n");
			break;
		}
	}
}
