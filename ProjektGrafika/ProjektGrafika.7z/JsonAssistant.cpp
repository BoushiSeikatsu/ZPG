#include "JsonAssistant.h"

void JsonAssistant::saveScene(string fileName, map<int, DrawableObject*> listOfModels, map<int, ShaderProgram*> listOfShaderPrograms, map<int, TransformationComposite*> listOfTransformations, map<int, Lighting*> listOfLights, Camera* camera)
{

}
