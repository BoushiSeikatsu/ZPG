#include "Transformation.h"

/*
void Transformation::rotate(float angle, glm::vec3 rotationAxis)
{
	this->M = glm::rotate(M, angle, rotationAxis);
}
void Transformation::translate(glm::vec3 translationVector)
{
	M = glm::translate(M, translationVector);
}
void Transformation::scale(glm::vec3 scalingVector)
{
	M = glm::scale(M, scalingVector);
}
*/